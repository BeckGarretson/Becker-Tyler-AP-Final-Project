#include <iostream>
#include <vector>
#include <time.h>
#include <cstdlib>
#include <ctime>
#include <fstream>
using namespace std;

bool guessVerify(string guessedWord);

string guessCheck(string guessedWord, string actualWord);

int main() {
  ifstream in;
  in.open("possible.txt");
  if(in.fail()){
    cout << "File didn't open"<<endl;
  }

  srand(time(0));
  int randomNumber = rand() % 2500;

  vector<string>  words;
  for (int i = 0; i < 2500; i++){
    string w;
    getline(in, w);
    words.push_back(w);
    if (in.fail()) break;
  }
  string guess = "";
  int count = 0;
  while(guess!=words[randomNumber] && count != 8){
    cout<<endl<<"Guess a 5-letter Word!"<<endl;
    cin>>guess;
    while(guessVerify(guess)==false){
      cout<<"Guess a 5-letter Word!"<<endl;
      cin>>guess;
      guessVerify(guess);
    }
    string fad = guessCheck(guess, words[randomNumber]);
    count++;
  }
  if(count==8){
    cout<<"You're a disapointment to your family.";
  }
}

bool guessVerify(string guessedWord){
  if(guessedWord.length()!=5){
    return false;
  }else{
    return true;
  }
}

string guessCheck(string guessedWord, string actualWord){
  string hold = "-----";
  for(int k = 0; k<5; k++){
    if(guessedWord[k]==actualWord[k]){
      hold[k]=actualWord[k];
    }
  }
  cout<<hold<<endl;
  if(guessedWord==actualWord){
    cout<<endl<<"Yay! You got it! The word was "<<actualWord<<"!"<<endl;
  }
  return hold;
}